import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-initial-compo',
  templateUrl: './initial-compo.component.html',
  styleUrls: ['./initial-compo.component.css']
})
export class InitialCompoComponent implements OnInit {

  constructor() {
    console.log('ICI constructor de AppModule - InitialCompo !!!');
  }

  ngOnInit() {
    console.log('ICI ngOnInit de AppModule - InitialCompo !!!');
  }

}
