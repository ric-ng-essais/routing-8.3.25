import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-found-compo',
  templateUrl: './not-found-compo.component.html',
  styleUrls: ['./not-found-compo.component.css']
})
export class NotFoundCompoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
